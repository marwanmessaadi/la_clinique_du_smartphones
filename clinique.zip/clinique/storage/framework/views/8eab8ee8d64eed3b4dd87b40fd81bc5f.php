

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Détail de la catégorie</h1>
    <div class="card">
        <div class="card-body">
            <h3 class="card-title"><?php echo e($categorie->nom); ?></h3>
            <p class="card-text"><strong>Description :</strong> <?php echo e($categorie->description); ?></p>
            <p class="card-text"><strong>Crée le :</strong> <?php echo e($categorie->created_at->format('d/m/Y')); ?></p>
            <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-secondary">Retour à la liste</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Desktop\clinique\resources\views/categories/show.blade.php ENDPATH**/ ?>