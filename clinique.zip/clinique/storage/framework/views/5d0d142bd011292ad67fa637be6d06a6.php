
<?php $__env->startSection('title', 'modifier un Produit'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="h3 mb-4 text-gray-800">Modifier un Produit</h1>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('produits.update', $produit->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="nom">Nom</label>
                <input type="text" class="form-control" id="nom" name="nom" value="<?php echo e($produit->nom); ?>" required>
            </div>
            <div class="form-group">
                <label for="description">Description</label>
                <textarea class="form-control" id="description" name="description" rows="3"><?php echo e($produit->description); ?></textarea>
            </div>
            <div class="form-group">
                <label for="image">Image</label>
                <input type="file" class="form-control" id="image" name="image" accept="image/*">
                <?php if($produit->image): ?>
                    <img src="<?php echo e(asset('storage/' . $produit->image)); ?>" alt="<?php echo e($produit->nom); ?>" width="100">
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="prix_achat">Prix d'achat</label>
                <input type="number" class="form-control" id="prix_achat" name="prix_achat" value="<?php echo e($produit->prix_achat); ?>" step="0.01" required>
            </div>
            <div class="form-group">
                <label for="prix_vente">Prix de vente</label>
                <input type="number" class="form-control" id="prix_vente" name="prix_vente" value="<?php echo e($produit->prix_vente); ?>" step="0.01" required>
            </div>
                <div class="form-group">
                <label for="prix_gros">Prix de gros</label>
                <input type="number" class="form-control" id="prix_gros" name="prix_gros" value="<?php echo e($produit->prix_gros); ?>" step="0.01" required>
            </div>
            <div class="form-group">
                <label for="prix_gros">Prix de gros</label>
                <input type="number" class="form-control" id="prix_gros" name="prix_gros" value="<?php echo e($produit->prix_gros); ?>" step="0.01" required>
            </div>
            <div class="form-group">
                <label for="quantite">Quantité</label>
                <input type="number" class="form-control" id="quantite" name="quantite" value="<?php echo e($produit->quantite); ?>" required>
            </div>
            <div class="form-group">
                <label for="categorie_id">Catégorie</label>
                <select class="form-control" id="categorie_id" name="categorie_id" required>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($categorie->id); ?>" <?php echo e($produit->categorie_id == $categorie->id ? 'selected' : ''); ?>>
                            <?php echo e($categorie->nom); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Modifier le Produit</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        $(document).ready(function() {
            $('form').on('submit', function(e) {
                e.preventDefault();
                Swal.fire({
                    title: 'Êtes-vous sûr ?',
                    text: "Vous ne pourrez pas revenir en arrière !",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Oui, modifiez-le !'
                }).then((result) => {
                    if (result.isConfirmed) {
                        this.submit();
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Desktop\clinique\resources\views/produits/edit.blade.php ENDPATH**/ ?>