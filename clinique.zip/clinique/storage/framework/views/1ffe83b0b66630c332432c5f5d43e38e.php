
<?php $__env->startSection('title', 'liste des Réparations'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- Messages -->
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Formulaire de recherche -->
    <form method="GET" action="<?php echo e(route('reparation.search')); ?>" class="mb-4">
        <div class="row">
            <div class="col-md-3">
                <input type="text" name="nom" class="form-control" placeholder="Nom du client" value="<?php echo e(request('nom')); ?>">
            </div>
            <div class="col-md-3">
                <input type="text" name="code_barre" class="form-control" placeholder="Code barre" value="<?php echo e(request('code_barre')); ?>">
            </div>
            <div class="col-md-3">
                <select name="etat" class="form-control">
                    <option value="">-- État --</option>
                    <option value="en_cours" <?php echo e(request('etat') == 'en_cours' ? 'selected' : ''); ?>>En cours</option>
                    <option value="terminee" <?php echo e(request('etat') == 'terminee' ? 'selected' : ''); ?>>Terminée</option>
                    <option value="annulee" <?php echo e(request('etat') == 'annulee' ? 'selected' : ''); ?>>Annulée</option>
                </select>
            </div>
            <div class="col-md-3">
                <button type="submit" class="btn btn-primary">Rechercher</button>
                <a href="<?php echo e(route('reparation.index')); ?>" class="btn btn-secondary">Réinitialiser</a>
            </div>
        </div>
    </form>

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Liste des Réparations</h1>
        <a href="<?php echo e(route('reparation.create')); ?>" class="btn btn-primary">Créer une Réparation</a>
    </div>

    <!-- Table -->
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Nom du Client</th>
                <th>Description</th>
                <th>prix</th>
                <th>Date de Réparation</th>
                <th>Produit</th>
                <th>État</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $reparations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reparation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($reparation->nom); ?></td>
                    <td><?php echo e($reparation->description); ?></td>
                    <td><?php echo e($reparation->prix); ?></td>
                    <td><?php echo e($reparation->date_reparation); ?></td>
                    <td><?php echo e($reparation->produit); ?></td>
                    <td>
                        <?php if($reparation->etat == 'en_cours'): ?>
                            <span style="background:#fffbe6;color:#b8860b;padding:4px 12px;border-radius:4px;border:1px solid #ffe58f;">En cours</span>
                        <?php elseif($reparation->etat == 'terminee'): ?>
                            <span style="background:#e6ffed;color:#389e0d;padding:4px 12px;border-radius:4px;border:1px solid #b7eb8f;">Terminée</span>
                        <?php elseif($reparation->etat == 'annulee'): ?>
                            <span style="background:#fff1f0;color:#cf1322;padding:4px 12px;border-radius:4px;border:1px solid #ffa39e;">Annulée</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('reparation.edit', $reparation->id)); ?>" class="btn btn-warning btn-sm">Modifier</a>
                        <form action="<?php echo e(route('reparation.destroy', $reparation->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm">Supprimer</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <!-- Pagination -->
    <?php echo e($reparations->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Desktop\clinique\resources\views/reparations/index.blade.php ENDPATH**/ ?>