
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; La Clinique du Smartphone <?php echo e(date('Y')); ?></span>
        </div>
    </div>
</footer><?php /**PATH C:\Users\user\Desktop\clinique\resources\views/partials/footer.blade.php ENDPATH**/ ?>