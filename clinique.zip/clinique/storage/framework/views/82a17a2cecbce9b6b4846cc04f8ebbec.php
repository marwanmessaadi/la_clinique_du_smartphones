
<?php $__env->startSection('title', 'Créer une Catégorie'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <h1 class="h3 mb-4 text-gray-800">Créer une Catégorie</h1>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('categories.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="name">Nom de la Catégorie</label>
                <input type="text" class="form-control" id="name" name="nom" placeholder="Entrez le nom de la catégorie" required>
            </div>
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-plus"></i> Ajouter
            </button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Desktop\clinique\resources\views/categories/create.blade.php ENDPATH**/ ?>