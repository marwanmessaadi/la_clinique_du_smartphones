
<?php $__env->startSection('title', 'Liste des Utilisateurs'); ?>
<?php $__env->startSection('content'); ?>
<style>
    .old-table-bg {
        background: #eaeaea;
        border: 1px solid #b0b0b0;
        padding: 30px;
        font-family: Arial, Helvetica, sans-serif;
        color: #222;
        max-width: 900px;
        margin: 40px auto;
        box-shadow: 2px 2px 8px #bbb;
    }
    .old-table-title {
        font-size: 22px;
        font-weight: bold;
        margin-bottom: 20px;
        text-align: center;
        color: #333;
    }
    .old-table {
        width: 100%;
        border-collapse: collapse;
        background: #fff;
        margin-bottom: 20px;
    }
    .old-table th, .old-table td {
        border: 1px solid #888;
        padding: 8px 12px;
        font-size: 15px;
        text-align: left;
    }
    .old-table th {
        background: #d4d4d4;
        color: #222;
        font-weight: bold;
    }
    .old-table tr:nth-child(even) {
        background: #f4f4f4;
    }
    .old-btn {
        background: #d4d4d4;
        color: #222;
        border: 1px solid #888;
        padding: 5px 15px;
        font-size: 14px;
        border-radius: 0;
        cursor: pointer;
        margin-right: 5px;
        text-decoration: none;
        display: inline-block;
    }
    .old-btn:hover {
        background: #b0b0b0;
    }
</style>
<div class="old-table-bg">
    <div class="old-table-title">Liste des Utilisateurs</div>
    <a href="<?php echo e(route('utilisateurs.create')); ?>" class="old-btn">Créer un Utilisateur</a>
    <table class="old-table">
        <thead>
            <tr>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Email</th>
                <th>Rôle</th>
                <th>Téléphone</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $utilisateurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $utilisateur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($utilisateur->nom); ?></td>
                    <td><?php echo e($utilisateur->prenom); ?></td>
                    <td><?php echo e($utilisateur->email); ?></td>
                    <td><?php echo e($utilisateur->role); ?></td>
                    <td><?php echo e($utilisateur->telephone); ?></td>
                    <td>
                        <a href="<?php echo e(route('utilisateurs.edit', $utilisateur->id)); ?>" class="old-btn">Modifier</a>
                        <form action="<?php echo e(route('utilisateurs.destroy', $utilisateur->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="old-btn" onclick="return confirm('Confirmer la suppression ?')">Supprimer</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Desktop\clinique\resources\views/utilisateurs/index.blade.php ENDPATH**/ ?>