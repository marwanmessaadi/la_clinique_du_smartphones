
<?php $__env->startSection('title', 'Modifier un Utilisateur'); ?>
<?php $__env->startSection('content'); ?>
<style>
    .old-form-bg {
        background: #eaeaea;
        border: 1px solid #b0b0b0;
        padding: 30px;
        font-family: Arial, Helvetica, sans-serif;
        color: #222;
        max-width: 500px;
        margin: 40px auto;
        box-shadow: 2px 2px 8px #bbb;
    }
    .old-form-label {
        font-weight: bold;
        display: block;
        margin-bottom: 5px;
    }
    .old-form-input, .old-form-select {
        width: 100%;
        padding: 7px;
        border: 1px solid #888;
        border-radius: 0;
        background: #fff;
        margin-bottom: 15px;
        font-size: 15px;
    }
    .old-form-btn {
        background: #d4d4d4;
        color: #222;
        border: 1px solid #888;
        padding: 7px 25px;
        font-size: 15px;
        border-radius: 0;
        cursor: pointer;
        margin-right: 10px;
    }
    .old-form-btn:hover {
        background: #b0b0b0;
    }
    .old-form-title {
        font-size: 22px;
        font-weight: bold;
        margin-bottom: 20px;
        text-align: center;
        color: #333;
    }
    .alert-danger {
        background: #ffeaea;
        border: 1px solid #d88;
        color: #a00;
        padding: 10px;
        margin-bottom: 20px;
    }
</style>
<div class="old-form-bg">
    <div class="old-form-title">Modifier un Utilisateur</div>
    <!-- Affichage des erreurs -->
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('utilisateurs.update', $utilisateur->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <label for="name" class="old-form-label">Nom</label>
        <input type="text" id="name" name="nom" class="old-form-input"
               value="<?php echo e(old('nom', $utilisateur->nom)); ?>" required>

        <label for="prenom" class="old-form-label">Prénom</label>
        <input type="text" id="prenom" name="prenom" class="old-form-input"
               value="<?php echo e(old('prenom', $utilisateur->prenom)); ?>" required>

        <label for="email" class="old-form-label">Email</label>
        <input type="email" id="email" name="email" class="old-form-input"
               value="<?php echo e(old('email', $utilisateur->email)); ?>" required>

        <label for="password" class="old-form-label">Mot de Passe <span style="color:#888;font-size:13px;">(laisser vide pour ne pas changer)</span></label>
        <input type="password" id="password" name="mot_de_passe" class="old-form-input">

        <label for="telephone" class="old-form-label">Téléphone</label>
        <input type="text" id="telephone" name="telephone" class="old-form-input"
               value="<?php echo e(old('telephone', $utilisateur->telephone)); ?>" maxlength="10">

        <label for="role" class="old-form-label">Rôle</label>
        <select id="role" name="role" class="old-form-select" required>
            <option value="admin" <?php echo e(old('role', $utilisateur->role) == 'admin' ? 'selected' : ''); ?>>Admin</option>
            <option value="client" <?php echo e(old('role', $utilisateur->role) == 'client' ? 'selected' : ''); ?>>Client</option>
        </select>

        <button type="submit" class="old-form-btn">Modifier</button>
        <a href="<?php echo e(route('utilisateurs.index')); ?>" class="old-form-btn">Annuler</a>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        // Custom scripts can be added here
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Desktop\clinique\resources\views/utilisateurs/edit.blade.php ENDPATH**/ ?>