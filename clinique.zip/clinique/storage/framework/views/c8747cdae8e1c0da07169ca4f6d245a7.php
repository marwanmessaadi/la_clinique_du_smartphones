
<?php $__env->startSection('title', 'Liste des Catégories'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!-- Page Heading -->
        <h1 class="h3 mb-4 text-gray-800">Liste des Catégories</h1>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <!-- Bouton Ajouter une Catégorie -->
        <div class="mb-4">
            <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary">
                <i class="fas fa-plus"></i> Ajouter une Catégorie
            </a>
        </div>

        <!-- Formulaire de recherche -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Rechercher une Catégorie</h6>
            </div>
            <div class="card-body">
                <form method="GET" action="<?php echo e(route('categories.searchByName')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="name">Rechercher par Nom</label>
                        <input type="text" class="form-control" id="name" name="name" placeholder="Entrez le nom de la catégorie">
                    </div>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-search"></i> Rechercher
                    </button>
                </form>
            </div>
        </div>

        <!-- Liste des Catégories -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Toutes les Catégories</h6>
            </div>
            <div class="card-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nom</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($categorie->id); ?></td>
                                <td><?php echo e($categorie->nom); ?></td>
                                <td>
                                    <a href="<?php echo e(route('categories.show', $categorie->id)); ?>" class="btn btn-info btn-sm">
                                        <i class="fas fa-eye"></i> Voir
                                    </a>
                                    <a href="<?php echo e(route('categories.edit', $categorie->id)); ?>" class="btn btn-warning btn-sm">
                                        <i class="fas fa-edit"></i> Modifier
                                    </a>
                                    <form method="POST" action="<?php echo e(route('categories.destroy', $categorie->id)); ?>" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette catégorie ?')">
                                            <i class="fas fa-trash"></i> Supprimer
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Desktop\clinique\resources\views/categories/index.blade.php ENDPATH**/ ?>