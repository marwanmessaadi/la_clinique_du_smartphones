

<?php $__env->startSection('title', 'Liste des Produits'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!-- Page Heading -->
        <h1 class="h3 mb-4 text-gray-800">Liste des Produits</h1>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <!-- Boutons Ajouter un Produit Achat et Vente -->
        <div class="mb-4">
            <a href="<?php echo e(route('produits.create', ['type' => 'achat'])); ?>" class="btn btn-success mr-2">
                <i class="fas fa-plus"></i> Ajouter un Produit Achat
            </a>
            <a href="<?php echo e(route('produits.create_vente', ['type' => 'vente'])); ?>" class="btn btn-primary">
                <i class="fas fa-plus"></i> Ajouter un Produit Vente
            </a>
        </div>

        <!-- Tableau des produits -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Liste des Produits</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Nom</th>
                                <th>Description</th>
                                <th>Prix d'achat</th>
                                <th>Prix de vente</th>
                                <th>Prix de gros</th>
                                <th>Catégorie</th>
                                <th>statut</th>
                                <th>Quantité</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($produit->nom); ?></td>
                                    <td><?php echo e($produit->description); ?></td>
                                    <td><?php echo e($produit->prix_achat); ?></td>
                                    <td><?php echo e($produit->prix_vente); ?></td>
                                    <td><?php echo e($produit->prix_gros); ?></td>
                                    <td><?php echo e($produit->categorie ? $produit->categorie->nom : 'Non renseignée'); ?></td>
                                    
                                    <td>
                                        <?php if($produit->type == 'achat'): ?>
                                            <span style="background:#fffbe6;color:#b8860b;padding:4px 12px;border-radius:4px;border:1px solid #ffe58f;">Achat</span>
                                        <?php elseif($produit->type == 'vente'): ?>
                                            <span style="background:#e6ffed;color:#389e0d;padding:4px 12px;border-radius:4px;border:1px solid #b7eb8f;">Vente</span>
                                        <?php else: ?>
                                            <span style="background:#f0f0f0;color:#888;padding:4px 12px;border-radius:4px;"><?php echo e(ucfirst($produit->type)); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
    <?php if($produit->quantite == 0): ?>
        <span style="color:#cf1322;font-weight:bold;">Indisponible</span>
    <?php else: ?>
        <?php echo e($produit->quantite); ?>

    <?php endif; ?>
</td>
                                    <td>
                                        <a href="<?php echo e(route('produits.edit', $produit->id)); ?>" class="btn btn-sm btn-warning">
                                            <i class="fas fa-edit"></i> Modifier
                                        </a>
                                        <form action="<?php echo e(route('produits.destroy', $produit->id)); ?>" method="POST" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger">
                                                <i class="fas fa-trash"></i> Supprimer
                                            </button>
                                        </form>
                                        <a href="<?php echo e(route('produits.show', $produit->id)); ?>" class="btn btn-sm btn-info">
                                            <i class="fas fa-eye"></i> Voir
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Desktop\clinique\resources\views/produits/index.blade.php ENDPATH**/ ?>