
<?php $__env->startSection('title', 'Détails du Produit'); ?>

<?php $__env->startSection('content'); ?>
    <h1><?php echo e($produit->nom); ?></h1>
    <p><strong>Prix d'achat :</strong> <?php echo e($produit->prix_achat); ?> DH</p>
    <p><strong>Prix de vente :</strong> <?php echo e($produit->prix_vente); ?> DH</p>
    <p><strong>Prix de gros :</strong> <?php echo e($produit->prix_gros); ?> DH</p>
    <p><strong>Quantité :</strong> <?php echo e($produit->quantite); ?></p>
    <p><strong>Description :</strong> <?php echo e($produit->description); ?></p>

    <h2>Catégorie</h2>
    <p>
        <?php echo e($produit->categorie ? $produit->categorie->nom : 'Non renseignée'); ?>

    </p>

    <?php if($produit->image): ?>
        <div>
            <img src="<?php echo e(asset('storage/' . $produit->image)); ?>" alt="Image du produit" style="max-width:200px;">
        </div>
    <?php endif; ?>

    <a href="<?php echo e(route('produits.index')); ?>" class="btn btn-secondary mt-3">Retour à la liste</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Desktop\clinique\resources\views/produits/show.blade.php ENDPATH**/ ?>