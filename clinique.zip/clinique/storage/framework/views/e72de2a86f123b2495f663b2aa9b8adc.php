
<?php $__env->startSection('title', 'Liste et Création des Clients'); ?>
<?php $__env->startSection('content'); ?>
<style>
    .old-table-bg {
        background: #eaeaea;
        border: 1px solid #b0b0b0;
        padding: 30px;
        font-family: Arial, Helvetica, sans-serif;
        color: #222;
        max-width: 1000px;
        margin: 40px auto;
        box-shadow: 2px 2px 8px #bbb;
    }
    .old-table-title {
        font-size: 22px;
        font-weight: bold;
        margin-bottom: 20px;
        text-align: center;
        color: #333;
    }
    .old-form-row {
        display: flex;
        gap: 20px;
    }
    .old-form-col {
        flex: 1;
    }
    .old-form-label {
        font-weight: bold;
        display: block;
        margin-bottom: 5px;
    }
    .old-form-input, .old-form-select {
        width: 100%;
        padding: 7px;
        border: 1px solid #888;
        border-radius: 0;
        background: #fff;
        margin-bottom: 15px;
        font-size: 15px;
    }
    .old-form-btn {
        background: #d4d4d4;
        color: #222;
        border: 1px solid #888;
        padding: 7px 25px;
        font-size: 15px;
        border-radius: 0;
        cursor: pointer;
        margin-right: 10px;
    }
    .old-form-btn:hover {
        background: #b0b0b0;
    }
    .alert-danger {
        background: #ffeaea;
        border: 1px solid #d88;
        color: #a00;
        padding: 10px;
        margin-bottom: 20px;
    }
    .old-table {
        width: 100%;
        border-collapse: collapse;
        background: #fff;
        margin-bottom: 20px;
    }
    .old-table th, .old-table td {
        border: 1px solid #888;
        padding: 8px 12px;
        font-size: 15px;
        text-align: left;
    }
    .old-table th {
        background: #d4d4d4;
        color: #222;
        font-weight: bold;
    }
    .old-table tr:nth-child(even) {
        background: #f4f4f4;
    }
    .old-btn {
        background: #d4d4d4;
        color: #222;
        border: 1px solid #888;
        padding: 5px 15px;
        font-size: 14px;
        border-radius: 0;
        cursor: pointer;
        margin-right: 5px;
        text-decoration: none;
        display: inline-block;
    }
    .old-btn:hover {
        background: #b0b0b0;
    }
    .alert-success {
        background: #e0ffe0;
        border: 1px solid #8d8;
        color: #080;
        padding: 10px;
        margin-bottom: 20px;
    }
</style>
<div class="old-table-bg">
    <div class="old-table-title">Créer un Client</div>
    <?php if($errors->any()): ?>
        <div class="alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php if(session('success')): ?>
        <div class="alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <form method="POST" action="<?php echo e(route('clients.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="old-form-row">
            <div class="old-form-col">
                <label for="nom" class="old-form-label">Nom</label>
                <input type="text" class="old-form-input" id="nom" name="nom" value="<?php echo e(old('nom')); ?>" required>
            </div>
            <div class="old-form-col">
                <label for="prenom" class="old-form-label">Prénom</label>
                <input type="text" class="old-form-input" id="prenom" name="prenom" value="<?php echo e(old('prenom')); ?>" required>
            </div>
        </div>
        <div class="old-form-row">
            <div class="old-form-col">
                <label for="email" class="old-form-label">Email</label>
                <input type="email" class="old-form-input" id="email" name="email" value="<?php echo e(old('email')); ?>" required>
            </div>
            <div class="old-form-col">
                <label for="telephone" class="old-form-label">Téléphone</label>
                <input type="text" class="old-form-input" id="telephone" name="telephone" value="<?php echo e(old('telephone')); ?>" required>
            </div>
        </div>
        <div class="old-form-row">
            <div class="old-form-col">
                <label for="mot_de_passe" class="old-form-label">Mot de Passe</label>
                <input type="password" class="old-form-input" id="mot_de_passe" name="mot_de_passe" required>
            </div>
            <div class="old-form-col">
                <label for="mot_de_passe_confirmation" class="old-form-label">Confirmer le Mot de Passe</label>
                <input type="password" class="old-form-input" id="mot_de_passe_confirmation" name="mot_de_passe_confirmation" required>
            </div>
        </div>
        <div class="old-form-row">
            <div class="old-form-col">
                <label for="role" class="old-form-label">Rôle</label>
                <select class="old-form-select" id="role" name="role" required>
                    <option value="client">Client</option>
                </select>
            </div>
            <div class="old-form-col" style="display: flex; align-items: flex-end;">
                <button type="submit" class="old-form-btn">Créer</button>
            </div>
        </div>
    </form>
    <hr>
    <div class="old-table-title">Liste des Clients</div>
    <table class="old-table">
        <thead>
            <tr>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Email</th>
                <th>Téléphone</th>
                <th>Rôle</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($client->nom); ?></td>
                    <td><?php echo e($client->prenom); ?></td>
                    <td><?php echo e($client->email); ?></td>
                    <td><?php echo e($client->telephone); ?></td>
                    <td><?php echo e($client->role); ?></td>
                    <td>
                        <a href="<?php echo e(route('clients.edit', $client->id)); ?>" class="old-btn">Modifier</a>
                        <form action="<?php echo e(route('clients.destroy', $client->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="old-btn" onclick="return confirm('Confirmer la suppression ?')">Supprimer</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Desktop\clinique\resources\views/clients/index.blade.php ENDPATH**/ ?>