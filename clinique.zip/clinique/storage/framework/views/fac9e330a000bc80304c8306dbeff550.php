

<?php $__env->startSection('title', 'Nouvelle Vente'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Nouvelle Vente</h1>

    
    <form method="GET" action="<?php echo e(route('produits.create_vente')); ?>" class="mb-4">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Rechercher un produit..." value="<?php echo e(request('search')); ?>">
            <button class="btn btn-primary" type="submit">Rechercher</button>
        </div>
    </form>

    
    <?php if(isset($produits) && $produits->count()): ?>
        <div class="list-group mb-4">
            <?php $__currentLoopData = $produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('produits.create_vente', ['produit_id' => $produit->id])); ?>" class="list-group-item list-group-item-action">
                    <?php echo e($produit->nom); ?> (Stock: <?php echo e($produit->quantite); ?>) - <?php echo e($produit->prix_vente); ?> DH
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php elseif(request('search')): ?>
        <div class="alert alert-warning">Aucun produit trouvé.</div>
    <?php endif; ?>

    
    <?php if(isset($selectedProduit)): ?>
<?php if(isset($selectedProduit)): ?>
    <div class="card mb-4">
        <div class="card-header">
            <strong>Informations du produit</strong>
        </div>
        <div class="card-body">
            <p><strong>Nom :</strong> <?php echo e($selectedProduit->nom); ?></p>
            <p><strong>Description :</strong> <?php echo e($selectedProduit->description); ?></p>
            <p><strong>Prix de vente :</strong> <?php echo e($selectedProduit->prix_vente); ?> DH</p>
            <p><strong>Prix d'achat :</strong> <?php echo e($selectedProduit->prix_achat); ?> DH</p>
            <p><strong>Prix de gros :</strong> <?php echo e($selectedProduit->prix_gros); ?> DH</p>
            <p><strong>Date d'achat :</strong> <?php echo e($selectedProduit->date_achat); ?></p>
            <p><strong>Code barre :</strong> <?php echo e($selectedProduit->code_barre); ?></p>
            <p><strong>Quantité en stock :</strong> <?php echo e($selectedProduit->quantite); ?></p>
            <p><strong>Catégorie :</strong> <?php echo e($selectedProduit->categorie ? $selectedProduit->categorie->nom : 'Non renseignée'); ?></p>
        </div>
    </div>
<?php endif; ?>
    <form action="<?php echo e(route('ventes.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label class="form-label">Produit</label>
            <input type="text" class="form-control" value="<?php echo e($selectedProduit->nom); ?>" readonly>
            <input type="hidden" name="produit_id" value="<?php echo e($selectedProduit->id); ?>">
        </div>

        <div class="mb-3">
            <label for="prix_vente" class="form-label">Prix de vente (DH)</label>
            <input type="text" name="prix_vente" id="prix_vente" class="form-control" value="<?php echo e($selectedProduit->prix_vente); ?>" required>
        </div>

        <div class="mb-3">
            <label for="quantite" class="form-label">Quantité à vendre</label>
            <input type="number" name="quantite" id="quantite" class="form-control" min="1" max="<?php echo e($selectedProduit->quantite); ?>" required>
        </div>

        <button type="submit" class="btn btn-success">Valider la vente</button>
        <a href="<?php echo e(route('produits.vente')); ?>" class="btn btn-secondary">Annuler</a>
    </form>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Desktop\clinique\resources\views/ventes/create.blade.php ENDPATH**/ ?>