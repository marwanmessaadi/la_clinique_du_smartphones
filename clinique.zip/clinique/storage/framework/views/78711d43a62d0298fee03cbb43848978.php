
<?php $__env->startSection('title', 'Produits Achat'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="mb-4">Liste des Produits d'achat</h1>
        <a href="<?php echo e(route('produits.create', ['type' => 'achat'])); ?>" class="btn btn-primary mb-3">Ajouter un produit</a>
        <input type="hidden" name="type" value="achat">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>Prix d'achat</th>
                    <th>Quantité</th>
                    <th>Catégorie</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($produit->nom); ?></td>
                        <td><?php echo e($produit->prix_achat); ?> DH</td>
                        <td><?php echo e($produit->quantite); ?></td>
                        <td><?php echo e($produit->categorie ? $produit->categorie->nom : 'Non renseignée'); ?></td>
                        <td>
                            <a href="<?php echo e(route('produits.show', $produit->id)); ?>" class="btn btn-info btn-sm">Voir</a>
                            <a href="<?php echo e(route('produits.edit', $produit->id)); ?>" class="btn btn-warning btn-sm">Modifier</a>
                            <form action="<?php echo e(route('produits.destroy', $produit->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Supprimer ce produit ?')">Supprimer</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center">Aucun produit d'achat trouvé.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Desktop\clinique\resources\views/produits/index_achat.blade.php ENDPATH**/ ?>