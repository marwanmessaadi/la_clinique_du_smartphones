<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class fournisseur extends Model
{
    protected $table = 'fournisseur'; // Nom de la table dans la base de données
    protected $fillable = [
        'nom',
        'telephone',
    ];

    public function produits()
    {
        return $this->hasMany(Produits::class, 'fournisseur_id');
    }
}
