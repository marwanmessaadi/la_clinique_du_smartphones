<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Produits extends Model
{
    protected $table = 'produits'; // Nom de la table dans la base de données
    protected $fillable = [
        'nom',
        'description',
        'prix_achat',
        'prix_vente',
        'prix_gros',
        'quantite',
        'categorie_id',
        'fournisseur_id',
        'image',
    ];

    public function scopeSearch($query, $search)
    {
        return $query->where('nom', 'like', "%$search%")
            ->orWhere('description', 'like', "%$search%")
            ->orWhereHas('categorie', function ($query) use ($search) {
                $query->where('nom', 'like', "%$search%");
            });
    }
    public function categorie()
    {
        return $this->belongsTo(Categorie::class, 'categorie_id');
    }
    public function fournisseur()
    {
        return $this->belongsTo(Fournisseur::class, 'fournisseur_id');
    }

}
