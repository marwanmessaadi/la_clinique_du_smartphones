<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class reparation extends Model
{
    protected $table = 'reparation'; // Nom de la table dans la base de données
    protected $fillable = [
        'nom',
        'description',
        'prix',
        'date_reparation',
        'produit',
        'etat',
        'code_barre',
    ];

    public function scopeSearch($query, $search)
    {
        return $query->where('nom', 'like', "%$search%")
            ->orWhere('description', 'like', "%$search%");
    }
}
