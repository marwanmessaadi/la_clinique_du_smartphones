<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Reparation;
use Milon\Barcode\DNS1D; // Ajoute ce use en haut du fichier

class ReparationController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $reparations = Reparation::paginate(10);
        return view('reparations.index', compact('reparations'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('reparations.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'nom' => 'required|string|max:255',
            'description' => 'nullable|string',
            'prix' => 'required|numeric',
            'date_reparation' => 'nullable|date',
            'produit' => 'required|string|max:255',
            'etat' => 'required|in:en_cours,terminee,annulee',
            'code_barre' => 'nullable|string|unique:reparation,code_barre',
        ]);

        Reparation::create($request->all());

        return redirect()->route('reparation.index')->with('success', 'Réparation créée avec succès.');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $reparation = Reparation::findOrFail($id);
        return view('reparations.show', compact('reparation'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $reparation = Reparation::findOrFail($id);
        return view('reparations.edit', compact('reparation'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $request->validate([
            'nom' => 'required|string|max:255',
            'description' => 'nullable|string',
            'prix' => 'required|numeric',
            'date_reparation' => 'nullable|date',
            'produit' => 'required|string|max:255',
            'etat' => 'required|in:en_cours,terminee,annulee',
            'code_barre' => 'nullable|string|unique:reparation,code_barre,' . $id,
        ]);

        $reparation = Reparation::findOrFail($id);
        $reparation->update($request->all());

        return redirect()->route('reparation.index')->with('success', 'Réparation mise à jour avec succès.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $reparation = Reparation::findOrFail($id);
        $reparation->delete();

        return redirect()->route('reparation.index')->with('success', 'Réparation supprimée avec succès.');
    }

    /**
     * Search reparations by nom, code_barre or etat.
     */
    public function search(Request $request)
    {
        $query = Reparation::query();

        if ($request->filled('nom')) {
            $query->where('nom', 'like', '%' . $request->nom . '%');
        }
        if ($request->filled('code_barre')) {
            $query->where('code_barre', 'like', '%' . $request->code_barre . '%');
        }
        if ($request->filled('etat')) {
            $query->where('etat', $request->etat);
        }
        $reparations = $query->paginate(10)->appends($request->except('page'));

        return view('reparations.index', compact('reparations'));
    }

    /**
     * Affiche le code-barres de la réparation.
     */
    public function barcode($id)
    {
        $reparation = Reparation::findOrFail($id);
        $barcode = null;
        if ($reparation->code_barre) {
            $barcode = (new DNS1D())->getBarcodeHTML($reparation->code_barre, 'C128');
        }
        return view('reparations.barcode', compact('reparation', 'barcode'));
    }
}
