<?php

namespace App\Http\Controllers;
use App\Models\Produits;
use Illuminate\Http\Request;

class VenteController extends Controller
{
     public function create(Request $request)
    {
        $produits = collect();
        $selectedProduit = null;

        // Recherche de produits
        if ($request->filled('search')) {
            $produits = Produits::where('type', 'achat')
                ->where('nom', 'like', '%' . $request->search . '%')
                ->where('quantite', '>', 0)
                ->get();
        }

        // Sélection d'un produit
        if ($request->filled('produit_id')) {
            $selectedProduit = Produits::find($request->produit_id);
        }

        return view('ventes.create', compact('produits', 'selectedProduit'));
    }

    /**
     * Enregistre une vente.
     */
    public function storeVente(Request $request)
    {
        $validated = $request->validate([
            'produit_id' => 'required|exists:produits,id',
            'quantite' => 'required|integer|min:1',
        ]);

        $produit = Produits::findOrFail($validated['produit_id']);

        if ($produit->quantite < $validated['quantite']) {
            return back()->withErrors(['quantite' => 'Stock insuffisant pour cette vente.']);
        }

        // Décrémente le stock et change le type
        $produit->quantite -= $validated['quantite'];
        $produit->type = 'vente';
        $produit->save();

        // Ici tu peux enregistrer la vente dans une table "ventes" si tu en as une

        return redirect()->route('produits.vente')->with('success', 'Vente enregistrée avec succès.');
    }
}
