<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Produits;
use App\Models\Categorie;

class ProduitsController extends Controller
{
    /**
     * Affiche la liste des produits.
     */
    public function index()
    {
        $produits = Produits::all();
        return view('produits.index', compact('produits'));
    }

    /**
     * Affiche la liste des produits d'achat.
     */
    public function indexAchat()
    {
        $produits = Produits::where('type', 'achat')->get();
        return view('produits.index_achat', compact('produits'));
    }

    /**
     * Affiche la liste des produits de vente.
     */
    public function indexVente()
    {
        $produits = Produits::where('type', 'vente')->get();
        return view('produits.index_vente', compact('produits'));
    }

    /**
     * Affiche le formulaire de création.
     */
    public function create()
    {
        $categories = Categorie::orderBy('nom')->get();
        return view('produits.create', compact('categories'));
    }

    /**
     * Enregistre un nouveau produit.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nom' => 'required|string|max:255|unique:produits',
            'description' => 'nullable|string',
            'prix_achat' => 'required|numeric|min:0',
            'prix_vente' => 'required|numeric|min:0|gt:prix_achat',
            'prix_gros' => 'required|numeric|min:0|gte:prix_achat|lte:prix_vente',
            'quantite' => 'required|integer|min:0',
            'image' => 'nullable|image|max:2048',
            'categorie_id' => 'required|exists:categories,id',
        ]);

        try {
            $produit = new Produits();
            $produit->nom = $validated['nom'];
            $produit->description = $validated['description'];
            $produit->prix_achat = $validated['prix_achat'];
            $produit->prix_vente = $validated['prix_vente'];
            $produit->prix_gros = $validated['prix_gros'];
            $produit->quantite = $validated['quantite'];
            $produit->categorie_id = $validated['categorie_id'];

            if ($request->hasFile('image')) {
                $imagePath = $request->file('image')->store('produits', 'public');
                $produit->image = $imagePath;
            }

            $produit->etat = 'disponible';

            $produit->save();

            return redirect()->route('produits.index')
                ->with('success', 'Produit ajouté avec succès.');
        } catch (\Exception $e) {
            \Log::error('Erreur lors de la création du produit: ' . $e->getMessage());
            return back()
                ->withInput()
                ->withErrors(['error' => 'Une erreur est survenue lors de l\'ajout du produit: ' . $e->getMessage()]);
        }
    }

    /**
     * Affiche un produit.
     */
    public function show(string $id)
    {
        $produit = Produits::findOrFail($id);
        return view('produits.show', compact('produit'));
    }

    /**
     * Affiche le formulaire d'édition.
     */
    public function edit(string $id)
    {
        $produit = Produits::findOrFail($id);
        $categories = Categorie::orderBy('nom')->get();
        return view('produits.edit', compact('produit', 'categories'));
    }

    /**
     * Met à jour un produit.
     */
    public function update(Request $request, string $id)
    {
        $validated = $request->validate([
            'nom' => 'required|string|max:255',
            'description' => 'nullable|string',
            'prix_achat' => 'required|numeric|min:0',
            'prix_vente' => 'required|numeric|min:0|gt:prix_achat',
            'prix_gros' => 'required|numeric|min:0|gte:prix_achat|lte:prix_vente',
            'quantite' => 'required|integer|min:0',
            'image' => 'nullable|image|max:2048',
            'categorie_id' => 'required|exists:categories,id',
        ]);

        $produit = Produits::findOrFail($id);

        $produit->nom = $validated['nom'];
        $produit->description = $validated['description'];
        $produit->prix_achat = $validated['prix_achat'];
        $produit->prix_vente = $validated['prix_vente'];
        $produit->prix_gros = $validated['prix_gros'];
        $produit->quantite = $validated['quantite'];
        $produit->categorie_id = $validated['categorie_id'];

        if ($request->hasFile('image')) {
            $imagePath = $request->file('image')->store('produits', 'public');
            $produit->image = $imagePath;
        }

        $produit->save();

        return redirect()->route('produits.index')->with('success', 'Produit mis à jour avec succès.');
    }

    /**
     * Supprime un produit.
     */
    public function destroy(string $id)
    {
        $produit = Produits::findOrFail($id);
        $produit->delete();

        return redirect()->route('produits.index')->with('success', 'Produit supprimé avec succès.');
    }

    /**
     * Affiche le formulaire de création d'une vente.
     */
    public function searchByName(Request $request)
    {
        $query = $request->get('query');
        $produits = Produits::where('type', 'vente')
            ->where('quantite', '>', 0)
            ->where('nom', 'like', "%{$query}%")
            ->limit(10)
            ->get(['id', 'nom', 'prix_vente', 'quantite']);

        return response()->json($produits);
    }
}
