@extends('layouts.app')

@section('title', 'Inscription')

@section('content')
<style>
    .old-form-bg {
        background: #eaeaea;
        border: 1px solid #b0b0b0;
        padding: 30px;
        font-family: Arial, Helvetica, sans-serif;
        color: #222;
        max-width: 500px;
        margin: 40px auto;
        box-shadow: 2px 2px 8px #bbb;
    }
    .old-form-label {
        font-weight: bold;
        display: block;
        margin-bottom: 5px;
    }
    .old-form-input, .old-form-select {
        width: 100%;
        padding: 7px;
        border: 1px solid #888;
        border-radius: 0;
        background: #fff;
        margin-bottom: 15px;
        font-size: 15px;
    }
    .old-form-btn {
        background: #d4d4d4;
        color: #222;
        border: 1px solid #888;
        padding: 7px 25px;
        font-size: 15px;
        border-radius: 0;
        cursor: pointer;
        margin-right: 10px;
    }
    .old-form-btn:hover {
        background: #b0b0b0;
    }
    .old-form-title {
        font-size: 22px;
        font-weight: bold;
        margin-bottom: 20px;
        text-align: center;
        color: #333;
    }
    .alert-danger {
        background: #ffeaea;
        border: 1px solid #d88;
        color: #a00;
        padding: 10px;
        margin-bottom: 20px;
    }
</style>
<div class="old-form-bg">
    <div class="old-form-title">Créer un utilisateur</div>
    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form method="POST" action="{{ route('register.store') }}">
        @csrf
        <label for="nom" class="old-form-label">Nom</label>
        <input type="text" class="old-form-input" id="nom" name="nom" value="{{ old('nom') }}" required>

        <label for="prenom" class="old-form-label">Prénom</label>
        <input type="text" class="old-form-input" id="prenom" name="prenom" value="{{ old('prenom') }}" required>

        <label for="email" class="old-form-label">Adresse Email</label>
        <input type="email" class="old-form-input" id="email" name="email" value="{{ old('email') }}" required>

        <label for="mot_de_passe" class="old-form-label">Mot de Passe</label>
        <input type="password" class="old-form-input" id="mot_de_passe" name="mot_de_passe" required>

        <label for="mot_de_passe_confirmation" class="old-form-label">Confirmer le Mot de Passe</label>
        <input type="password" class="old-form-input" id="mot_de_passe_confirmation" name="mot_de_passe_confirmation" required>

        <label for="telephone" class="old-form-label">Téléphone</label>
        <input type="text" class="old-form-input" id="telephone" name="telephone" required>

        <label for="role" class="old-form-label">Rôle</label>
        <select class="old-form-select" id="role" name="role" required>
            <option value="admin">Admin</option>
            <option value="client">Client</option>
        </select>

        <button type="submit" class="old-form-btn">Créer</button>
        <a href="{{ route('utilisateurs.index') }}" class="old-form-btn">Annuler</a>
    </form>
</div>
@endsection
