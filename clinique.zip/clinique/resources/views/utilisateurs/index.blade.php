@extends('layouts.app')
@section('title', 'Liste des Utilisateurs')
@section('content')
<style>
    .old-table-bg {
        background: #eaeaea;
        border: 1px solid #b0b0b0;
        padding: 30px;
        font-family: Arial, Helvetica, sans-serif;
        color: #222;
        max-width: 900px;
        margin: 40px auto;
        box-shadow: 2px 2px 8px #bbb;
    }
    .old-table-title {
        font-size: 22px;
        font-weight: bold;
        margin-bottom: 20px;
        text-align: center;
        color: #333;
    }
    .old-table {
        width: 100%;
        border-collapse: collapse;
        background: #fff;
        margin-bottom: 20px;
    }
    .old-table th, .old-table td {
        border: 1px solid #888;
        padding: 8px 12px;
        font-size: 15px;
        text-align: left;
    }
    .old-table th {
        background: #d4d4d4;
        color: #222;
        font-weight: bold;
    }
    .old-table tr:nth-child(even) {
        background: #f4f4f4;
    }
    .old-btn {
        background: #d4d4d4;
        color: #222;
        border: 1px solid #888;
        padding: 5px 15px;
        font-size: 14px;
        border-radius: 0;
        cursor: pointer;
        margin-right: 5px;
        text-decoration: none;
        display: inline-block;
    }
    .old-btn:hover {
        background: #b0b0b0;
    }
</style>
<div class="old-table-bg">
    <div class="old-table-title">Liste des Utilisateurs</div>
    <a href="{{ route('utilisateurs.create') }}" class="old-btn">Créer un Utilisateur</a>
    <table class="old-table">
        <thead>
            <tr>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Email</th>
                <th>Rôle</th>
                <th>Téléphone</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach($utilisateurs as $utilisateur)
                <tr>
                    <td>{{ $utilisateur->nom }}</td>
                    <td>{{ $utilisateur->prenom }}</td>
                    <td>{{ $utilisateur->email }}</td>
                    <td>{{ $utilisateur->role }}</td>
                    <td>{{ $utilisateur->telephone }}</td>
                    <td>
                        <a href="{{ route('utilisateurs.edit', $utilisateur->id) }}" class="old-btn">Modifier</a>
                        <form action="{{ route('utilisateurs.destroy', $utilisateur->id) }}" method="POST" style="display:inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="old-btn" onclick="return confirm('Confirmer la suppression ?')">Supprimer</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection


