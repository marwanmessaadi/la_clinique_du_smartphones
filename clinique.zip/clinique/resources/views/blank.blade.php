@extends('layouts.app')

@section('title', 'Page Blanche')

@section('content')
    <!-- Begin Page Content -->
    <div class="container-fluid">
        <!-- Page Heading -->
        <h1 class="h3 mb-4 text-gray-800">Page Blanche</h1>

       
    </div>
    <!-- /.container-fluid -->
@endsection