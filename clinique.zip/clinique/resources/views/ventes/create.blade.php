@extends('layouts.app')

@section('title', 'Nouvelle Vente')

@section('content')
<div class="container">
    <h1>Nouvelle Vente</h1>

    {{-- Formulaire de recherche --}}
    <form method="GET" action="{{ route('produits.create_vente') }}" class="mb-4">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Rechercher un produit..." value="{{ request('search') }}">
            <button class="btn btn-primary" type="submit">Rechercher</button>
        </div>
    </form>

    {{-- Liste des produits trouvés --}}
    @if(isset($produits) && $produits->count())
        <div class="list-group mb-4">
            @foreach($produits as $produit)
                <a href="{{ route('produits.create_vente', ['produit_id' => $produit->id]) }}" class="list-group-item list-group-item-action">
                    {{ $produit->nom }} (Stock: {{ $produit->quantite }}) - {{ $produit->prix_vente }} DH
                </a>
            @endforeach
        </div>
    @elseif(request('search'))
        <div class="alert alert-warning">Aucun produit trouvé.</div>
    @endif

    {{-- Formulaire de vente si un produit est sélectionné --}}
    @if(isset($selectedProduit))
@if(isset($selectedProduit))
    <div class="card mb-4">
        <div class="card-header">
            <strong>Informations du produit</strong>
        </div>
        <div class="card-body">
            <p><strong>Nom :</strong> {{ $selectedProduit->nom }}</p>
            <p><strong>Description :</strong> {{ $selectedProduit->description }}</p>
            <p><strong>Prix de vente :</strong> {{ $selectedProduit->prix_vente }} DH</p>
            <p><strong>Prix d'achat :</strong> {{ $selectedProduit->prix_achat }} DH</p>
            <p><strong>Prix de gros :</strong> {{ $selectedProduit->prix_gros }} DH</p>
            <p><strong>Date d'achat :</strong> {{ $selectedProduit->date_achat }}</p>
            <p><strong>Code barre :</strong> {{ $selectedProduit->code_barre }}</p>
            <p><strong>Quantité en stock :</strong> {{ $selectedProduit->quantite }}</p>
            <p><strong>Catégorie :</strong> {{ $selectedProduit->categorie ? $selectedProduit->categorie->nom : 'Non renseignée' }}</p>
        </div>
    </div>
@endif
    <form action="{{ route('ventes.store') }}" method="POST">
        @csrf

        <div class="mb-3">
            <label class="form-label">Produit</label>
            <input type="text" class="form-control" value="{{ $selectedProduit->nom }}" readonly>
            <input type="hidden" name="produit_id" value="{{ $selectedProduit->id }}">
        </div>

        <div class="mb-3">
            <label for="prix_vente" class="form-label">Prix de vente (DH)</label>
            <input type="text" name="prix_vente" id="prix_vente" class="form-control" value="{{ $selectedProduit->prix_vente }}" required>
        </div>

        <div class="mb-3">
            <label for="quantite" class="form-label">Quantité à vendre</label>
            <input type="number" name="quantite" id="quantite" class="form-control" min="1" max="{{ $selectedProduit->quantite }}" required>
        </div>

        <button type="submit" class="btn btn-success">Valider la vente</button>
        <a href="{{ route('produits.vente') }}" class="btn btn-secondary">Annuler</a>
    </form>
    @endif
</div>
@endsection