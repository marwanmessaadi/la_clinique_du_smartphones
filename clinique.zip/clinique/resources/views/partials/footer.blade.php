{{-- filepath: c:\projet_de_stage_test\resources\views\partials\footer.blade.php --}}
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; La Clinique du Smartphone {{ date('Y') }}</span>
        </div>
    </div>
</footer>