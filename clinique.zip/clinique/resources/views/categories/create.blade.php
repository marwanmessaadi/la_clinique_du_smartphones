@extends('layouts.app')
@section('title', 'Créer une Catégorie')

@section('content')
    <div class="container-fluid">
        <h1 class="h3 mb-4 text-gray-800">Créer une Catégorie</h1>

        @if (session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif

        <form method="POST" action="{{ route('categories.store') }}">
            @csrf
            <div class="form-group">
                <label for="name">Nom de la Catégorie</label>
                <input type="text" class="form-control" id="name" name="nom" placeholder="Entrez le nom de la catégorie" required>
            </div>
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-plus"></i> Ajouter
            </button>
        </form>
    </div>
@endsection