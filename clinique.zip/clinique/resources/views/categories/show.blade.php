@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Détail de la catégorie</h1>
    <div class="card">
        <div class="card-body">
            <h3 class="card-title">{{ $categorie->nom }}</h3>
            <p class="card-text"><strong>Description :</strong> {{ $categorie->description }}</p>
            <p class="card-text"><strong>Crée le :</strong> {{ $categorie->created_at->format('d/m/Y') }}</p>
            <a href="{{ route('categories.index') }}" class="btn btn-secondary">Retour à la liste</a>
        </div>
    </div>
</div>
@endsection