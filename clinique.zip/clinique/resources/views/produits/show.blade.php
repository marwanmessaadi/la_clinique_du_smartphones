@extends('layouts.app')
@section('title', 'Détails du Produit')

@section('content')
    <h1>{{ $produit->nom }}</h1>
    <p><strong>Prix d'achat :</strong> {{ $produit->prix_achat }} DH</p>
    <p><strong>Prix de vente :</strong> {{ $produit->prix_vente }} DH</p>
    <p><strong>Prix de gros :</strong> {{ $produit->prix_gros }} DH</p>
    <p><strong>Quantité :</strong> {{ $produit->quantite }}</p>
    <p><strong>Description :</strong> {{ $produit->description }}</p>

    <h2>Catégorie</h2>
    <p>
        {{ $produit->categorie ? $produit->categorie->nom : 'Non renseignée' }}
    </p>

    @if($produit->image)
        <div>
            <img src="{{ asset('storage/' . $produit->image) }}" alt="Image du produit" style="max-width:200px;">
        </div>
    @endif

    <a href="{{ route('produits.index') }}" class="btn btn-secondary mt-3">Retour à la liste</a>
@endsection