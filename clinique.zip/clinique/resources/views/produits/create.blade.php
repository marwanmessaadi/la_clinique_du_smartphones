@extends('layouts.app')
@section('title', 'Ajouter un Produit')
@section('content')
    <div class="container">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Ajouter un Produit</h6>
            </div>
            <div class="card-body">
                @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <form action="{{ route('produits.store') }}" method="POST" enctype="multipart/form-data" id="productForm">
                    @csrf
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="nom">Nom du Produit</label>
                                <input type="text" class="form-control" id="nom" name="nom" value="{{ old('nom') }}" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="description">Description</label>
                                <textarea class="form-control" id="description" name="description" rows="3">{{ old('description') }}</textarea>
                            </div>
                            <div class="form-group">
                                <label for="categorie_id">Catégorie</label>
                                <select class="form-control" id="categorie_id" name="categorie_id">
                                    <option value="">Sélectionner une catégorie</option>
                                    @foreach($categories as $categorie)
                                        <option value="{{ $categorie->id }}" {{ old('categorie_id') == $categorie->id ? 'selected' : '' }}>
                                            {{ $categorie->nom }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="prix_achat">Prix d'achat</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" id="prix_achat" name="prix_achat" 
                                           step="0.01" min="0" value="{{ old('prix_achat') }}" required>
                                    <div class="input-group-append">
                                        <span class="input-group-text">DH</span>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="prix_vente">Prix de vente</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" id="prix_vente" name="prix_vente" 
                                           step="0.01" min="0" value="{{ old('prix_vente') }}" required>
                                    <div class="input-group-append">
                                        <span class="input-group-text">DH</span>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="prix_gros">Prix de gros</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" id="prix_gros" name="prix_gros" 
                                           step="0.01" min="0" value="{{ old('prix_gros') }}" required>
                                    <div class="input-group-append">
                                        <span class="input-group-text">DH</span>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="quantite">Quantité en stock</label>
                                <input type="number" class="form-control" id="quantite" name="quantite" 
                                       min="0" value="{{ old('quantite', 0) }}" required>
                            </div>

                            <div class="form-group">
                                <label for="image">Image du produit</label>
                                <input type="file" class="form-control" id="image" name="image" accept="image/*">
                            </div>
                        </div>
                    </div>

                    <div class="text-right mt-3">
                        <a href="{{ route('produits.index') }}" class="btn btn-secondary">Annuler</a>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Enregistrer le produit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
@section('scripts')
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        $(document).ready(function() {
            // Validation des prix
            $('#productForm').on('submit', function(e) {
                const prixAchat = parseFloat($('#prix_achat').val());
                const prixVente = parseFloat($('#prix_vente').val());
                const prixGros = parseFloat($('#prix_gros').val());

                if (prixVente <= prixAchat) {
                    e.preventDefault();
                    Swal.fire({
                        icon: 'error',
                        title: 'Erreur de prix',
                        text: 'Le prix de vente doit être supérieur au prix d\'achat!'
                    });
                    return false;
                }

                if (prixGros <= prixAchat || prixGros >= prixVente) {
                    e.preventDefault();
                    Swal.fire({
                        icon: 'error',
                        title: 'Erreur de prix',
                        text: 'Le prix de gros doit être compris entre le prix d\'achat et le prix de vente!'
                    });
                    return false;
                }
            });
        });
    </script>
@endsection