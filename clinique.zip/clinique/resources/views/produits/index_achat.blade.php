@extends('layouts.app')
@section('title', 'Produits Achat')

@section('content')
    <div class="container">
        <h1 class="mb-4">Liste des Produits d'achat</h1>
        <a href="{{ route('produits.create', ['type' => 'achat']) }}" class="btn btn-primary mb-3">Ajouter un produit</a>
        <input type="hidden" name="type" value="achat">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>Prix d'achat</th>
                    <th>Quantité</th>
                    <th>Catégorie</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($produits as $produit)
                    <tr>
                        <td>{{ $produit->nom }}</td>
                        <td>{{ $produit->prix_achat }} DH</td>
                        <td>{{ $produit->quantite }}</td>
                        <td>{{ $produit->categorie ? $produit->categorie->nom : 'Non renseignée' }}</td>
                        <td>
                            <a href="{{ route('produits.show', $produit->id) }}" class="btn btn-info btn-sm">Voir</a>
                            <a href="{{ route('produits.edit', $produit->id) }}" class="btn btn-warning btn-sm">Modifier</a>
                            <form action="{{ route('produits.destroy', $produit->id) }}" method="POST" style="display:inline;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Supprimer ce produit ?')">Supprimer</button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5" class="text-center">Aucun produit d'achat trouvé.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
@endsection