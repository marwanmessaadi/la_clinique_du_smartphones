@extends('layouts.app')
@section('title', 'modifier un Produit')
@section('content')
    <div class="container">
        <h1 class="h3 mb-4 text-gray-800">Modifier un Produit</h1>

        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form action="{{ route('produits.update', $produit->id) }}" method="POST" enctype="multipart/form-data">
            @csrf
            @method('PUT')
            <div class="form-group">
                <label for="nom">Nom</label>
                <input type="text" class="form-control" id="nom" name="nom" value="{{ $produit->nom }}" required>
            </div>
            <div class="form-group">
                <label for="description">Description</label>
                <textarea class="form-control" id="description" name="description" rows="3">{{ $produit->description }}</textarea>
            </div>
            <div class="form-group">
                <label for="image">Image</label>
                <input type="file" class="form-control" id="image" name="image" accept="image/*">
                @if ($produit->image)
                    <img src="{{ asset('storage/' . $produit->image) }}" alt="{{ $produit->nom }}" width="100">
                @endif
            </div>
            <div class="form-group">
                <label for="prix_achat">Prix d'achat</label>
                <input type="number" class="form-control" id="prix_achat" name="prix_achat" value="{{ $produit->prix_achat }}" step="0.01" required>
            </div>
            <div class="form-group">
                <label for="prix_vente">Prix de vente</label>
                <input type="number" class="form-control" id="prix_vente" name="prix_vente" value="{{ $produit->prix_vente }}" step="0.01" required>
            </div>
                <div class="form-group">
                <label for="prix_gros">Prix de gros</label>
                <input type="number" class="form-control" id="prix_gros" name="prix_gros" value="{{ $produit->prix_gros }}" step="0.01" required>
            </div>
            <div class="form-group">
                <label for="prix_gros">Prix de gros</label>
                <input type="number" class="form-control" id="prix_gros" name="prix_gros" value="{{ $produit->prix_gros }}" step="0.01" required>
            </div>
            <div class="form-group">
                <label for="quantite">Quantité</label>
                <input type="number" class="form-control" id="quantite" name="quantite" value="{{ $produit->quantite }}" required>
            </div>
            <div class="form-group">
                <label for="categorie_id">Catégorie</label>
                <select class="form-control" id="categorie_id" name="categorie_id" required>
                    @foreach ($categories as $categorie)
                        <option value="{{ $categorie->id }}" {{ $produit->categorie_id == $categorie->id ? 'selected' : '' }}>
                            {{ $categorie->nom }}
                        </option>
                    @endforeach
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Modifier le Produit</button>
        </form>
    </div>
@endsection
@section('scripts')
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        $(document).ready(function() {
            $('form').on('submit', function(e) {
                e.preventDefault();
                Swal.fire({
                    title: 'Êtes-vous sûr ?',
                    text: "Vous ne pourrez pas revenir en arrière !",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Oui, modifiez-le !'
                }).then((result) => {
                    if (result.isConfirmed) {
                        this.submit();
                    }
                });
            });
        });
    </script>
@endsection