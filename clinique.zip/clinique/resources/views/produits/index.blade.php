@extends('layouts.app')

@section('title', 'Liste des Produits')

@section('content')
    <div class="container-fluid">
        <!-- Page Heading -->
        <h1 class="h3 mb-4 text-gray-800">Liste des Produits</h1>

        @if (session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif

        <!-- Boutons Ajouter un Produit Achat et Vente -->
        <div class="mb-4">
            <a href="{{ route('produits.create', ['type' => 'achat']) }}" class="btn btn-success mr-2">
                <i class="fas fa-plus"></i> Ajouter un Produit Achat
            </a>
            <a href="{{ route('produits.create_vente', ['type' => 'vente']) }}" class="btn btn-primary">
                <i class="fas fa-plus"></i> Ajouter un Produit Vente
            </a>
        </div>

        <!-- Tableau des produits -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Liste des Produits</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Nom</th>
                                <th>Description</th>
                                <th>Prix d'achat</th>
                                <th>Prix de vente</th>
                                <th>Prix de gros</th>
                                <th>Catégorie</th>
                                <th>statut</th>
                                <th>Quantité</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($produits as $produit)
                                <tr>
                                    <td>{{ $produit->nom }}</td>
                                    <td>{{ $produit->description }}</td>
                                    <td>{{ $produit->prix_achat }}</td>
                                    <td>{{ $produit->prix_vente }}</td>
                                    <td>{{ $produit->prix_gros }}</td>
                                    <td>{{ $produit->categorie ? $produit->categorie->nom : 'Non renseignée' }}</td>
                                    
                                    <td>
                                        @if($produit->type == 'achat')
                                            <span style="background:#fffbe6;color:#b8860b;padding:4px 12px;border-radius:4px;border:1px solid #ffe58f;">Achat</span>
                                        @elseif($produit->type == 'vente')
                                            <span style="background:#e6ffed;color:#389e0d;padding:4px 12px;border-radius:4px;border:1px solid #b7eb8f;">Vente</span>
                                        @else
                                            <span style="background:#f0f0f0;color:#888;padding:4px 12px;border-radius:4px;">{{ ucfirst($produit->type) }}</span>
                                        @endif
                                    </td>
                                    <td>
    @if($produit->quantite == 0)
        <span style="color:#cf1322;font-weight:bold;">Indisponible</span>
    @else
        {{ $produit->quantite }}
    @endif
</td>
                                    <td>
                                        <a href="{{ route('produits.edit', $produit->id) }}" class="btn btn-sm btn-warning">
                                            <i class="fas fa-edit"></i> Modifier
                                        </a>
                                        <form action="{{ route('produits.destroy', $produit->id) }}" method="POST" style="display:inline;">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-sm btn-danger">
                                                <i class="fas fa-trash"></i> Supprimer
                                            </button>
                                        </form>
                                        <a href="{{ route('produits.show', $produit->id) }}" class="btn btn-sm btn-info">
                                            <i class="fas fa-eye"></i> Voir
                                        </a>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection