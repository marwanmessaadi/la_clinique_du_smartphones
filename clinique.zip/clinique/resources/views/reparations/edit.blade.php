@extends('layouts.app')
@section('title', 'Modifier une Réparation')
@section('content')
<div class="container">
    <!-- Messages -->
    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif
    @if($errors->any())
        <div class="alert alert-danger">
            <ul class="mb-0">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Modifier une Réparation</h1>
        <a href="{{ route('reparation.index') }}" class="btn btn-secondary">Retour à la liste</a>
    </div>

    <!-- Form -->
    <form action="{{ route('reparation.update', $reparation->id) }}" method="POST">
        @csrf
        @method('PUT')
        <div class="form-group">
            <label for="nom">Nom du Client</label>
            <input type="text" name="nom" id="nom" class="form-control" value="{{ old('nom', $reparation->nom) }}" required>
        </div>
        <div class="form-group">    
            <label for="description">Description</label>
            <input type="text" name="description" id="description" class="form-control" value="{{ old('description', $reparation->description) }}">
        </div>
        <div class="form-group">
            <label for="prix">Montant</label>
            <input type="number" step="0.01" name="prix" id="prix" class="form-control" value="{{ old('prix', $reparation->prix) }}" required>
        </div>
        <div class="form-group">
            <label for="date_reparation">Date de Réparation</label>
            <input type="date" name="date_reparation" id="date_reparation" class="form-control" value="{{ old('date_reparation', $reparation->date_reparation) }}">
        </div>
        <div class="form-group">
            <label for="produit">Produit</label>
            <input type="text" name="produit" id="produit" class="form-control" value="{{ old('produit', $reparation->produit) }}" required>
        </div>
        <div class="form-group">
            <label for="code_barre">Code Barre</label>
            <input type="text" name="code_barre" id="code_barre" class="form-control" value="{{ old('code_barre', $reparation->code_barre) }}">
        </div>
        <div class="form-group">
            <label for="etat">État</label>
            <select name="etat" id="etat" class="form-control" required>
                <option value="en_cours" {{ $reparation->etat == 'en_cours' ? 'selected' : '' }}>En Cours</option>
                <option value="terminee" {{ $reparation->etat == 'terminee' ? 'selected' : '' }}>Terminée</option>
                <option value="annulee" {{ $reparation->etat == 'annulee' ? 'selected' : '' }}>Annulée</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Mettre à jour</button>
    </form>
</div>
@endsection