@extends('layouts.app')
@section('title', 'Créer une Réparation')
@section('content')
<style>
    .old-form-bg {
        background: #eaeaea;
        border: 1px solid #b0b0b0;
        padding: 30px;
        font-family: Arial, Helvetica, sans-serif;
        color: #222;
        max-width: 600px;
        margin: 40px auto;
        box-shadow: 2px 2px 8px #bbb;
    }
    .old-form-title {
        font-size: 22px;
        font-weight: bold;
        margin-bottom: 20px;
        text-align: center;
        color: #333;
    }
    .old-form-row {
        display: flex;
        gap: 20px;
    }
    .old-form-col {
        flex: 1;
    }
    .old-form-label {
        font-weight: bold;
        display: block;
        margin-bottom: 5px;
    }
    .old-form-input, .old-form-select {
        width: 100%;
        padding: 7px;
        border: 1px solid #888;
        border-radius: 0;
        background: #fff;
        margin-bottom: 15px;
        font-size: 15px;
    }
    .old-form-btn {
        background: #d4d4d4;
        color: #222;
        border: 1px solid #888;
        padding: 7px 25px;
        font-size: 15px;
        border-radius: 0;
        cursor: pointer;
        margin-right: 10px;
    }
    .old-form-btn:hover {
        background: #b0b0b0;
    }
    .alert-danger {
        background: #ffeaea;
        border: 1px solid #d88;
        color: #a00;
        padding: 10px;
        margin-bottom: 20px;
    }
</style>
<div class="old-form-bg">
    <div class="old-form-title">Créer une Réparation</div>
    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif
    @if($errors->any())
        <div class="alert-danger">
            <ul class="mb-0">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('reparation.store') }}" method="POST">
        @csrf
        <div class="old-form-row">
            <div class="old-form-col">
                <label for="nom" class="old-form-label">Nom du Client</label>
                <input type="text" name="nom" id="nom" class="old-form-input" required>
            </div>
            <div class="old-form-col">
                <label for="description" class="old-form-label">Description</label>
                <input type="text" name="description" id="description" class="old-form-input" required>
            </div>
        </div>
        <div class="old-form-row">
            <div class="old-form-col">
                <label for="prix" class="old-form-label">Montant</label>
                <input type="number" step="0.01" name="prix" id="prix" class="old-form-input" required>
            </div>
            <div class="old-form-col">
                <label for="date_reparation" class="old-form-label">Date de Réparation</label>
                <input type="date" name="date_reparation" id="date_reparation" class="old-form-input" required>
            </div>
        </div>
        <div class="old-form-row">
            <div class="old-form-col">
                <label for="produit" class="old-form-label">Produit</label>
                <input type="text" name="produit" id="produit" class="old-form-input" required>
            </div>
            <div class="old-form-col">
                <label for="code_barre" class="old-form-label">Code Barre</label>
                <input type="text" name="code_barre" id="code_barre" class="old-form-input" required>
            </div>
        </div>
        <div class="old-form-row">
            <div class="old-form-col">
                <label for="etat" class="old-form-label">État</label>
                <select name="etat" id="etat" class="old-form-select" required>
                    <option value="en_cours">En Cours</option>
                    <option value="terminee">Terminée</option>
                    <option value="annulee">Annulée</option>
                </select>
            </div>
            <div class="old-form-col" style="display: flex; align-items: flex-end;">
                <button type="submit" class="old-form-btn">Créer</button>
                <a href="{{ route('reparation.index') }}" class="old-form-btn">Retour</a>
            </div>
        </div>
    </form>
</div>
@endsection