@extends('layouts.app')
@section('title', 'liste des Réparations')
@section('content')
<div class="container">
    <!-- Messages -->
    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif
    @if($errors->any())
        <div class="alert alert-danger">
            <ul class="mb-0">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <!-- Formulaire de recherche -->
    <form method="GET" action="{{ route('reparation.search') }}" class="mb-4">
        <div class="row">
            <div class="col-md-3">
                <input type="text" name="nom" class="form-control" placeholder="Nom du client" value="{{ request('nom') }}">
            </div>
            <div class="col-md-3">
                <input type="text" name="code_barre" class="form-control" placeholder="Code barre" value="{{ request('code_barre') }}">
            </div>
            <div class="col-md-3">
                <select name="etat" class="form-control">
                    <option value="">-- État --</option>
                    <option value="en_cours" {{ request('etat') == 'en_cours' ? 'selected' : '' }}>En cours</option>
                    <option value="terminee" {{ request('etat') == 'terminee' ? 'selected' : '' }}>Terminée</option>
                    <option value="annulee" {{ request('etat') == 'annulee' ? 'selected' : '' }}>Annulée</option>
                </select>
            </div>
            <div class="col-md-3">
                <button type="submit" class="btn btn-primary">Rechercher</button>
                <a href="{{ route('reparation.index') }}" class="btn btn-secondary">Réinitialiser</a>
            </div>
        </div>
    </form>

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Liste des Réparations</h1>
        <a href="{{ route('reparation.create') }}" class="btn btn-primary">Créer une Réparation</a>
    </div>

    <!-- Table -->
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Nom du Client</th>
                <th>Description</th>
                <th>prix</th>
                <th>Date de Réparation</th>
                <th>Produit</th>
                <th>État</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach($reparations as $reparation)
                <tr>
                    <td>{{ $reparation->nom }}</td>
                    <td>{{ $reparation->description }}</td>
                    <td>{{ $reparation->prix }}</td>
                    <td>{{ $reparation->date_reparation }}</td>
                    <td>{{ $reparation->produit }}</td>
                    <td>
                        @if($reparation->etat == 'en_cours')
                            <span style="background:#fffbe6;color:#b8860b;padding:4px 12px;border-radius:4px;border:1px solid #ffe58f;">En cours</span>
                        @elseif($reparation->etat == 'terminee')
                            <span style="background:#e6ffed;color:#389e0d;padding:4px 12px;border-radius:4px;border:1px solid #b7eb8f;">Terminée</span>
                        @elseif($reparation->etat == 'annulee')
                            <span style="background:#fff1f0;color:#cf1322;padding:4px 12px;border-radius:4px;border:1px solid #ffa39e;">Annulée</span>
                        @endif
                    </td>
                    <td>
                        <a href="{{ route('reparation.edit', $reparation->id) }}" class="btn btn-warning btn-sm">Modifier</a>
                        <form action="{{ route('reparation.destroy', $reparation->id) }}" method="POST" style="display:inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger btn-sm">Supprimer</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <!-- Pagination -->
    {{ $reparations->links() }}
</div>
@endsection